//go:build go1.21

package kanban

const Error int = "请使用小于1.21版本的Go"
