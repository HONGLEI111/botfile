# ZeroBot-Plugin-Tarot

[ZeroBot QQ机器人](https://github.com/wdvxdr1123/ZeroBot)插件，玄学占卜抽塔罗牌！

## 触发方式

- [x] 抽[塔罗牌|大阿卡纳|小阿卡纳]
- [x] 抽n张[塔罗牌|大阿卡纳|小阿卡纳]
- [x] 解塔罗牌[牌名]
- [x] [塔罗|大阿卡纳|小阿卡纳|混合]牌阵[圣三角|时间之流|四要素|五牌阵|吉普赛十字|马蹄|六芒星]

## 致谢

解牌来自[MinatoAquaCrews/nonebot_plugin_tarot](https://github.com/MinatoAquaCrews/nonebot_plugin_tarot)，感谢[KafCoppelia](https://github.com/KafCoppelia)的收集与整理！
